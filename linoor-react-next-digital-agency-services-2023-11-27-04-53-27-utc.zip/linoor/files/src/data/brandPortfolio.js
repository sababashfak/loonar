import bg from "@/images/update-09-06-2021/background/brand-bg-1-1.jpg";

const brandPortfolio = [
  {
    id: 1,
    bg,
    image: "brand-1-1.png",
    title: "sweety",
  },
  {
    id: 2,
    bg,
    image: "brand-1-2.png",
    title: "fastlane",
  },
  {
    id: 3,
    bg,
    image: "brand-1-3.png",
    title: "norcold",
  },
  {
    id: 4,
    bg,
    image: "brand-1-4.png",
    title: "bullseye",
  },
  {
    id: 5,
    bg,
    image: "brand-1-5.png",
    title: "golden",
  },
];

export default brandPortfolio;
