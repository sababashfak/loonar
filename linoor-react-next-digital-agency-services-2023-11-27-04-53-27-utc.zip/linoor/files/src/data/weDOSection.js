import featuredImage from "@/images/resource/featured-image-4.jpg";

const weDOSection = {
  title: "We do more then ever\nplatforms",
  featuredImage,
  text: "There are many variatns of passages the majority have suffered alteration in some foor randomised words believable.",
  barTitle: "Digital marketing",
  barPercent: 70,
  faqs: [
    {
      id: 1,
      title: "We help to create visual strategies",
      text: "There are many variations of passages the majority have suffered alteration in some fo injected humour, or randomised words believable.",
    },
    {
      id: 2,
      title: "Motion Graphics & Animations",
      text: "There are many variations of passages the majority have suffered alteration in some fo injected humour, or randomised words believable.",
    },
    {
      id: 3,
      title: "We help to achieve mutual goals",
      text: "There are many variations of passages the majority have suffered alteration in some fo injected humour, or randomised words believable.",
    },
  ],
};

export default weDOSection;
