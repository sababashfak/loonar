const faqs = [
  {
    id: 1,
    title: "We help to create visual strategies",
    text: "There are many variations of passages the majority have suffered alteration in some fo injected humour, or randomised words believable.",
  },
  {
    id: 2,
    title: "Motion Graphics & Animations",
    text: "There are many variations of passages the majority have suffered alteration in some fo injected humour, or randomised words believable.",
  },
  {
    id: 3,
    title: "We help to achieve mutual goals",
    text: "There are many variations of passages the majority have suffered alteration in some fo injected humour, or randomised words believable.",
  },
  {
    id: 4,
    title: "What happend to my design code",
    text: "There are many variations of passages the majority have suffered alteration in some fo injected humour, or randomised words believable.",
  },
  {
    id: 5,
    title: "what will be the cost of code",
    text: "There are many variations of passages the majority have suffered alteration in some fo injected humour, or randomised words believable.",
  },
];

export const faqsSection = [
  {
    id: 1,
    faqs,
    defaultCurrent: 1,
  },
  {
    id: 2,
    faqs,
    defaultCurrent: 4,
  },
];
