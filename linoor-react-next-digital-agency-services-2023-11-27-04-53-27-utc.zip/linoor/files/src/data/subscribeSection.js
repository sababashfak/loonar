export const subscribeOne = {
  title: "Subscribe to our newsletter to get daily content!",
  validate: "I agree to all terms and policies of the company",
};
