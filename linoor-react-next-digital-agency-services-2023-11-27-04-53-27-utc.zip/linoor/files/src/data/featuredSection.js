import image from "@/images/resource/featured-image-7.jpg";

const featuredSection = {
  image,
  title: "MAKE WEBSITES WITHOUT TOUCHING the CODing",
  text: "We are committed to providing our customers with exceptional service while offering our employees the best training. There are many variations of passages of lorem ipsum is simply free text available in the market, but the majority have suffered time.",
  features: [
    {
      id: 1,
      title: "Free Consultation",
      text: "Lorem ipsum is not dolor sit amet, consectetur notted.",
    },
    {
      id: 2,
      title: "Best team members",
      text: "Lorem ipsum is not dolor sit amet, consectetur notted.",
    },
  ],
};

export default featuredSection;
