export const historyTimeline = [
  {
    id: 1,
    year: 2010,
    items: [
      {
        id: 1,
        date: "20 April 2010",
        title: "Founding of a Linoor",
        text: "There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised. Suspendisse sollicitudin velit sed leo. Ut pharetra augue nec augue. Nam elit agna endrerit sit amet.",
      },
      {
        id: 2,
        date: "16 May 2010",
        title: "Company was growing",
        image: "history-1-1.jpg",
        text: "There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised. Suspendisse sollicitudin velit sed leo. Ut pharetra augue nec augue. Nam elit agna endrerit sit amet.",
      },
      {
        id: 3,
        date: "08 June 2010",
        title: "Won the first award",
        text: "There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised. Suspendisse sollicitudin velit sed leo. Ut pharetra augue nec augue. Nam elit agna endrerit sit amet.",
      },
    ],
  },
  {
    id: 2,
    year: 2016,
    items: [
      {
        id: 1,
        date: "20 April 2016",
        title: "popular in media",
        text: "There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised. Suspendisse sollicitudin velit sed leo. Ut pharetra augue nec augue. Nam elit agna endrerit sit amet.",
      },
      {
        id: 2,
        date: "16 May 2016",
        title: "leading in business",
        image: "history-1-2.jpg",
        text: "There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised. Suspendisse sollicitudin velit sed leo. Ut pharetra augue nec augue. Nam elit agna endrerit sit amet.",
      },
      {
        id: 3,
        date: "08 June 2016",
        title: "Among top 10 companies",
        text: "There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised. Suspendisse sollicitudin velit sed leo. Ut pharetra augue nec augue. Nam elit agna endrerit sit amet.",
      },
    ],
  },
];
