export const howItWorksPage = [
  {
    id: 1,
    icon: "flaticon-development1",
    title: "meet experts",
    href: "/team",
    text: "Lorem Ipsum available, but the majority have suffer alteration in the some form.",
  },
  {
    id: 2,
    icon: "flaticon-vector",
    title: "business ideas",
    href: "/about",
    text: "Lorem Ipsum available, but the majority have suffer alteration in the some form.",
  },
  {
    id: 3,
    icon: "flaticon-monitoring",
    title: "get success",
    href: "/contact",
    text: "Lorem Ipsum available, but the majority have suffer alteration in the some form.",
  },
];
