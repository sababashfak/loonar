import bg2 from "@/images/update-01-10-2021/background/video-seven-1-1.jpg";
import bg from "@/images/update-01-10-2021/background/video-six-bg-1.jpg";
import image from "@/images/update-26-02-2021/resources/video-2-1.jpg";

export const videoSix = {
  bg,
  title: "Delivering only exceptional quality work",
  videoId: "8DP4NgupAhI",
  text: "Watch video",
};

export const videoSeven = {
  bg: bg2,
  title: "Mission is to Protect Your Business & More",
  videoId: "8DP4NgupAhI",
};

export const videoOne = {
  image,
  videoId: "y2Eqx6ys1hQ",
  title: "Linoor is trusted by millions of customers",
  text1:
    "Lorem ipsum dolors sit amet elit magnis amet ultrices purusrfed aliquet. There are many variations of passages of available but the majority have suffered.",
  text2:
    "Tincidunt elit magnis nulla facilisis sagittis maecenas. Sapien nunced amet ultrices, dolores sit ipsum velit purus aliquet.",
};
