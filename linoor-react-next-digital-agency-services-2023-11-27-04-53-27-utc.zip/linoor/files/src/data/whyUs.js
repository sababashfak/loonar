import image from "@/images/resource/featured-image-8.jpg";

const whyUs = {
  image,
  videoId: "Get7rqXYrbQ",
  title: "See Why you should choose linoor",
  features: [
    {
      id: 1,
      title: "We think differently",
      text: "Lorem Ipsum nibh vel velit auctor aliquet. Aenean sollic tudin, lorem is simply free text quis bibendum.",
    },
    {
      id: 2,
      title: "did High quality projects",
      text: "Lorem Ipsum nibh vel velit auctor aliquet. Aenean sollic tudin, lorem is simply free text quis bibendum.",
    },
    {
      id: 3,
      title: "super expert team members",
      text: "Lorem Ipsum nibh vel velit auctor aliquet. Aenean sollic tudin, lorem is simply free text quis bibendum.",
    },
  ],
};

export default whyUs;
