export const cartPage = {
  items: ["Item", "Price", "Quantity", "Total", "Remove"],
  products: [
    {
      id: 1,
      image: "cart-1-1.jpg",
      title: "comfy chair",
      price: 9.99,
      quantity: 1,
    },
    {
      id: 2,
      image: "cart-1-2.jpg",
      title: "classic chair",
      price: 9.99,
      quantity: 1,
    },
  ],
};
