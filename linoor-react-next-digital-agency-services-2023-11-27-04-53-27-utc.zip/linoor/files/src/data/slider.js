export const sliderSix = [
  {
    id: 1,
    bg: "slider-six-1-1.jpg",
    text: "Welcome to best linoor business agency",
    title: "meet the corporate \n business agency",
  },
  {
    id: 2,
    bg: "slider-six-1-2.jpg",
    text: "Welcome to best linoor business agency",
    title: "meet the corporate \n business agency",
  },
];

export const sliderSeven = [
  {
    id: 1,
    bg: "slider-seven-1-1.jpg",
    title: "We Deliver the Quality Seo Links.",
    titleHighlight: "Quality",
    text: "We’re committed to providing customers exceptional service offering employees the best training.",
  },
  {
    id: 2,
    bg: "slider-seven-1-2.jpg",
    title: "We Deliver the Quality Seo Links.",
    titleHighlight: "Quality",
    text: "We’re committed to providing customers exceptional service offering employees the best training.",
  },
];

export const sliderEight = [
  {
    id: 1,
    bg: "slider-eight-1-1.jpg",
    text: "Helping businesses since 1987",
    title: "Reach the Limits with Consulting Agency.",
  },
  {
    id: 2,
    bg: "slider-eight-1-2.jpg",
    text: "Helping businesses since 1987",
    title: "Reach the Limits with Consulting Agency.",
  },
];
