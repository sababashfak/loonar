import bg from "@/images/update-1-12-2020/background/call-bg-1-1.jpg";

export const callToSectionThree = {
  bg,
  title: "We’re Helping Over 8000 Businesses",
};
