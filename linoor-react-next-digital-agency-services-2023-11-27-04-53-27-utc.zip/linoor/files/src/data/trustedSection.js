import image from "@/images/resource/featured-image-5.jpg";

const trustedSection = {
  title: "We’re Committed To Deliver High Quality Projects.",
  title2: "We’re trusted by more\nthan 6260 clients",
  image,
  text: "There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, simply free text by injected humour, or randomised.",
  textList: [
    "Suspe ndisse sagittis leo.",
    "Entum estibulum is posuere.",
    "If you are going to use passage.",
    "Lorem Ipsum on the tend to repeat.",
  ],
  features: [
    {
      id: 1,
      title: "TOTAL DESIGN FREEDOM FOR EVERYONE",
      subtitle: "core features",
    },
    {
      id: 2,
      title: "BASIC RULES OF RUNNING WEB AGENCY",
      subtitle: "core features",
    },
  ],
};

export default trustedSection;
