export const processOne = [
  {
    id: 1,
    image: "grow-1-1.png",
    title: "got an new idea",
    text: "Lorem Ipsum is simply dummy text of free available in market the printing and typesetting industry has been the industry's standard dummy text ever. Vivamus semper nulla quis ipsum maximus, vulputate volutpat augue varius. Aliquam rhoncus ullamcorper est.",
    lists: [
      "Suspe ndisse suscipit sagittis leo.",
      "Entum estibulum dignissim posuere.",
      "If you are going to use a passage.",
      "Nulla quis ipsum maximus.",
    ],
  },
  {
    id: 2,
    image: "grow-1-2.png",
    title: "consult with team",
    text: "Lorem Ipsum is simply dummy text of free available in market the printing and typesetting industry has been the industry's standard dummy text ever. Vivamus semper nulla quis ipsum maximus, vulputate volutpat augue varius. Aliquam rhoncus ullamcorper est.",
    lists: [
      "Suspe ndisse suscipit sagittis leo.",
      "Entum estibulum dignissim posuere.",
      "If you are going to use a passage.",
      "Nulla quis ipsum maximus.",
    ],
  },
  {
    id: 3,
    image: "grow-1-3.png",
    title: "make a schedule",
    text: "Lorem Ipsum is simply dummy text of free available in market the printing and typesetting industry has been the industry's standard dummy text ever. Vivamus semper nulla quis ipsum maximus, vulputate volutpat augue varius. Aliquam rhoncus ullamcorper est.",
    lists: [
      "Suspe ndisse suscipit sagittis leo.",
      "Entum estibulum dignissim posuere.",
      "If you are going to use a passage.",
      "Nulla quis ipsum maximus.",
    ],
  },
  {
    id: 4,
    image: "grow-1-4.png",
    title: "grow & enjoy",
    text: "Lorem Ipsum is simply dummy text of free available in market the printing and typesetting industry has been the industry's standard dummy text ever. Vivamus semper nulla quis ipsum maximus, vulputate volutpat augue varius. Aliquam rhoncus ullamcorper est.",
    lists: [
      "Suspe ndisse suscipit sagittis leo.",
      "Entum estibulum dignissim posuere.",
      "If you are going to use a passage.",
      "Nulla quis ipsum maximus.",
    ],
  },
];
