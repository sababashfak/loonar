const discoverSection = {
  title: "Discover the world of best\nlinoor agency",
  discovers: [
    {
      id: 1,
      image: "featured-image-11.jpg",
      title: "All-in-One Web Solution for Your Business",
    },
    {
      id: 2,
      image: "featured-image-12.jpg",
      title: "The best digital agency you’ll ever need",
    },
  ],
};

export default discoverSection;
