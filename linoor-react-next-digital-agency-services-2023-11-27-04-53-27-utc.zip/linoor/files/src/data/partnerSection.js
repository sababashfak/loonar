export const partnerOne = [
  {
    id: 1,
    image: "sponsor-3-1.png",
    title: "yoga balance",
    text: "Lorem ipsum is simply free sed qui magni dolores eos qui voptam.",
  },
  {
    id: 2,
    image: "sponsor-3-2.png",
    title: "natural",
    text: "Lorem ipsum is simply free sed qui magni dolores eos qui voptam.",
  },
  {
    id: 3,
    image: "sponsor-3-3.png",
    title: "cosmetics",
    text: "Lorem ipsum is simply free sed qui magni dolores eos qui voptam.",
  },
  {
    id: 4,
    image: "sponsor-3-4.png",
    title: "Message Spa",
    text: "Lorem ipsum is simply free sed qui magni dolores eos qui voptam.",
  },
  {
    id: 5,
    image: "sponsor-3-5.png",
    title: "organic product",
    text: "Lorem ipsum is simply free sed qui magni dolores eos qui voptam.",
  },
  {
    id: 6,
    image: "sponsor-3-6.png",
    title: "Girl power",
    text: "Lorem ipsum is simply free sed qui magni dolores eos qui voptam.",
  },
];
