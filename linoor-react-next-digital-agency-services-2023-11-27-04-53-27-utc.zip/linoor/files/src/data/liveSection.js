import bg from "@/images/resource/featured-image-3.jpg";
import bg2 from "@/images/update-1-12-2020/background/video-bg-1-1.jpg";

const liveSection = {
  secTitle: "Experience us live",
  bg,
  videoId: "Get7rqXYrbQ",
  title: "agency that gets\nexcited about",
};

export default liveSection;

export const liveSectionTwo = {
  bg: bg2,
  tagline: "Client Testimonials",
  title: "We’re Delivering only Expectional Quality Work",
  videoId: "Get7rqXYrbQ",
};
