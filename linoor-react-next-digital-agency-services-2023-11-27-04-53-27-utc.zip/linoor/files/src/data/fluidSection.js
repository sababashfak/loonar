const fluidSection = [
  {
    id: 1,
    bg: "image-4.jpg",
    title: "BUILD a BETTER WEBSITE ALOT QUICKER WITH linoor",
    href: "/about",
    btnClassName: "btn-style-one",
  },
  {
    id: 2,
    bg: "image-5.jpg",
    title: "We provide our customers with exceptional service",
    href: "/contact",
    btnClassName: "btn-style-two",
  },
];

export default fluidSection;
